<?php
function civicrmVersion( ) {
  return array( 'version'  => '5.0.0',
                'cms'      => 'Wordpress',
                'revision' => '' );
}

