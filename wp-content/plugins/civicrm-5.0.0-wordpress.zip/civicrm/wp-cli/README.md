wp-cli-civicrm
==============

WP-CLI integration for CiviCRM
